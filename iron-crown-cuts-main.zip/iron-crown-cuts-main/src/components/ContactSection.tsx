import { motion } from "framer-motion";
import { MapPin, Phone, Clock, Instagram, Facebook } from "lucide-react";

const transition = { duration: 0.4, ease: [0.4, 0, 0.2, 1] as const };

const ContactSection = () => {
  return (
    <section id="kontaktai" className="section-padding border-t border-border">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={transition}
          className="mb-16"
        >
          <p className="text-primary text-sm uppercase tracking-[0.3em] mb-4 font-body font-bold">Kontaktai</p>
          <h2 className="font-display text-4xl md:text-5xl text-foreground">Susisiekite su mumis</h2>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={transition}
            className="space-y-8"
          >
            <div className="flex items-start gap-4">
              <MapPin className="w-5 h-5 text-primary mt-1 shrink-0" />
              <div>
                <p className="text-foreground font-body font-bold mb-1">Adresas</p>
                <p className="text-muted-foreground font-body">Gedimino pr. 1, Vilnius, LT-01103</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <Phone className="w-5 h-5 text-primary mt-1 shrink-0" />
              <div>
                <p className="text-foreground font-body font-bold mb-1">Telefonas</p>
                <a href="tel:+37060000000" className="text-primary hover:text-foreground transition-colors font-body">
                  +370 600 00 000
                </a>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <Clock className="w-5 h-5 text-primary mt-1 shrink-0" />
              <div>
                <p className="text-foreground font-body font-bold mb-1">Darbo laikas</p>
                <div className="text-muted-foreground font-body space-y-1">
                  <p>Pirmadienis – Penktadienis: 9:00 – 20:00</p>
                  <p>Šeštadienis: 10:00 – 18:00</p>
                  <p>Sekmadienis: Nedirbame</p>
                </div>
              </div>
            </div>

            <div className="flex gap-4 pt-4">
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors" aria-label="Instagram">
                <Instagram className="w-6 h-6" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors" aria-label="Facebook">
                <Facebook className="w-6 h-6" />
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ ...transition, delay: 0.2 }}
            className="w-full aspect-video luxury-shadow overflow-hidden"
          >
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2306.1!2d25.2798!3d54.6892!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNTTCsDQxJzIxLjEiTiAyNcKwMTYnNDcuMyJF!5e0!3m2!1slt!2slt!4v1"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="The Iron Crown Barbershop lokacija"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
