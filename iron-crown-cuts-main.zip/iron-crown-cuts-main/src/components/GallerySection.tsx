import { motion } from "framer-motion";
import galleryFade from "@/assets/gallery-fade.jpg";
import galleryBeard from "@/assets/gallery-beard.jpg";
import galleryInterior from "@/assets/gallery-interior.jpg";
import galleryCrop from "@/assets/gallery-crop.jpg";
import galleryTools from "@/assets/gallery-tools.jpg";
import heroImage from "@/assets/hero-barbershop.jpg";

const images = [
  { src: galleryFade, alt: "Skin fade kirpimas" },
  { src: galleryBeard, alt: "Barzdos formavimas" },
  { src: galleryInterior, alt: "Barbershop interjeras" },
  { src: galleryCrop, alt: "Modernus kirpimas" },
  { src: galleryTools, alt: "Profesionalūs įrankiai" },
  { src: heroImage, alt: "Kirpėjas darbe" },
];

const transition = { duration: 0.4, ease: [0.4, 0, 0.2, 1] as const };

const GallerySection = () => {
  return (
    <section id="galerija" className="section-padding">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={transition}
          className="mb-16"
        >
          <p className="text-primary text-sm uppercase tracking-[0.3em] mb-4 font-body font-bold">Galerija</p>
          <h2 className="font-display text-4xl md:text-5xl text-foreground">Mūsų darbai</h2>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {images.map((img, i) => (
            <motion.div
              key={img.alt}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ ...transition, delay: i * 0.08 }}
              className="overflow-hidden group"
            >
              <img
                src={img.src}
                alt={img.alt}
                className="w-full aspect-square object-cover grayscale hover:grayscale-0 transition-all duration-500 group-hover:scale-105"
                loading="lazy"
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default GallerySection;
