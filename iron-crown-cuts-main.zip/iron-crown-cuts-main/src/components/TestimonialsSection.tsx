import { motion } from "framer-motion";
import { Star } from "lucide-react";

const testimonials = [
  { name: "Tomas R.", text: "Geriausias barbershop mieste. Kiekvienas kirpimas tobulas, o aptarnavimas — aukščiausio lygio.", rating: 5 },
  { name: "Mantas K.", text: "Skin fade čia daromas meistriškai. Niekur kitur neinu jau 3 metus. Rekomenduoju visiems.", rating: 5 },
  { name: "Lukas P.", text: "Profesionalumas ir dėmesys detalėms. Barzda atrodo geriau nei bet kada. Ačiū komandai!", rating: 5 },
];

const transition = { duration: 0.4, ease: [0.4, 0, 0.2, 1] as const };

const TestimonialsSection = () => {
  return (
    <section id="atsiliepimai" className="section-padding">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={transition}
          className="mb-16"
        >
          <p className="text-primary text-sm uppercase tracking-[0.3em] mb-4 font-body font-bold">Atsiliepimai</p>
          <h2 className="font-display text-4xl md:text-5xl text-foreground">Ką sako klientai</h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ ...transition, delay: i * 0.1 }}
              className="bg-secondary p-8 luxury-shadow"
            >
              <div className="flex gap-1 mb-4">
                {Array.from({ length: t.rating }).map((_, j) => (
                  <Star key={j} className="w-4 h-4 fill-primary text-primary" />
                ))}
              </div>
              <p className="text-muted-foreground font-body leading-relaxed mb-6">"{t.text}"</p>
              <p className="text-foreground font-body font-bold text-sm uppercase tracking-widest">{t.name}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
