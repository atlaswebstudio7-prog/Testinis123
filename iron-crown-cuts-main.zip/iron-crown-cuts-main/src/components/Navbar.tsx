import { useState } from "react";
import { Menu, X } from "lucide-react";

const navLinks = [
  { label: "Paslaugos", href: "#paslaugos" },
  { label: "Apie mus", href: "#apie" },
  { label: "Galerija", href: "#galerija" },
  { label: "Atsiliepimai", href: "#atsiliepimai" },
  { label: "Kontaktai", href: "#kontaktai" },
];

const Navbar = () => {
  const [open, setOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between h-16 md:h-20">
        <a href="#" className="font-display text-xl md:text-2xl text-foreground tracking-tight">
          The Iron Crown
        </a>

        {/* Desktop */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="relative text-sm uppercase tracking-widest text-muted-foreground hover:text-foreground transition-colors duration-300 group font-body"
            >
              {link.label}
              <span className="absolute left-0 -bottom-1 h-px w-0 bg-primary transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
          <a
            href="#rezervacija"
            className="bg-primary text-primary-foreground px-6 py-2.5 text-xs uppercase tracking-widest font-bold transition-all hover:scale-105 active:scale-95 animate-pulse-gold"
          >
            Rezervuoti
          </a>
        </div>

        {/* Mobile toggle */}
        <button
          onClick={() => setOpen(!open)}
          className="md:hidden text-foreground"
          aria-label="Menu"
        >
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden bg-background border-t border-border px-6 pb-6 pt-4 space-y-4">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setOpen(false)}
              className="block text-sm uppercase tracking-widest text-muted-foreground hover:text-foreground transition-colors font-body"
            >
              {link.label}
            </a>
          ))}
          <a
            href="#rezervacija"
            onClick={() => setOpen(false)}
            className="block text-center bg-primary text-primary-foreground px-6 py-3 text-xs uppercase tracking-widest font-bold"
          >
            Rezervuoti laiką
          </a>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
