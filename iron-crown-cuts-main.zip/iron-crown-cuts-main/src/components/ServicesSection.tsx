import { motion } from "framer-motion";
import { Scissors, Sparkles } from "lucide-react";

const services = [
  { title: "Vyriškas kirpimas", price: "€25", description: "Klasikinis arba modernus kirpimas pagal jūsų stilių ir veido formą.", icon: Scissors },
  { title: "Skin Fade", price: "€30", description: "Preciziškas skin fade su švaria linija ir tobulu perėjimu.", icon: Sparkles },
  { title: "Barzdos tvarkymas", price: "€15", description: "Profesionalus barzdos formavimas ir priežiūra su karštu rankšluosčiu.", icon: Scissors },
  { title: "Kirpimas + Barzda", price: "€35", description: "Pilnas transformacijos paketas — kirpimas ir barzdos tvarkymas vienu metu.", icon: Sparkles },
];

const transition = { duration: 0.4, ease: [0.4, 0, 0.2, 1] as const };

const ServicesSection = () => {
  return (
    <section id="paslaugos" className="section-padding">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={transition}
          className="mb-16"
        >
          <p className="text-primary text-sm uppercase tracking-[0.3em] mb-4 font-body font-bold">Paslaugos</p>
          <h2 className="font-display text-4xl md:text-5xl text-foreground">Mūsų paslaugos</h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {services.map((s, i) => (
            <motion.div
              key={s.title}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ ...transition, delay: i * 0.1 }}
              className="group bg-secondary p-8 md:p-10 transition-all duration-500 hover:gold-glow-hover luxury-shadow"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <s.icon className="w-5 h-5 text-primary" />
                  <h3 className="font-display text-xl md:text-2xl text-foreground">{s.title}</h3>
                </div>
                <span className="text-primary font-body font-bold text-lg">{s.price}</span>
              </div>
              <p className="text-muted-foreground font-body leading-relaxed">{s.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
