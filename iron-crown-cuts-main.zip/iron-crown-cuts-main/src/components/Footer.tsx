const Footer = () => {
  return (
    <footer className="border-t border-border py-8 px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <p className="font-display text-lg text-foreground">The Iron Crown</p>
        <p className="text-sm text-muted-foreground font-body">
          © {new Date().getFullYear()} The Iron Crown Barbershop. Visos teisės saugomos.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
