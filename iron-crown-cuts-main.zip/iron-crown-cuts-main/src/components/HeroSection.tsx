import { motion } from "framer-motion";
import heroImage from "@/assets/hero-barbershop.jpg";

const transition = { duration: 0.6, ease: [0.4, 0, 0.2, 1] as const };

const HeroSection = () => {
  return (
    <section className="relative min-h-svh flex items-center justify-center overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="Profesionalus kirpėjas atlieka modernų fade kirpimą"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/60 to-background" />
        <div className="absolute inset-0 bg-gradient-to-r from-background/80 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 py-32 w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ ...transition, delay: 0.2 }}
          className="max-w-2xl"
        >
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ ...transition, delay: 0.1 }}
            className="text-primary text-sm uppercase tracking-[0.3em] mb-6 font-body font-bold"
          >
            The Iron Crown Barbershop
          </motion.p>
          <h1 className="font-display text-5xl md:text-7xl lg:text-8xl text-foreground leading-[0.95] mb-8">
            Tobulas kirpimas.
            <br />
            <span className="text-primary">Tikras vyriškas</span>
            <br />
            stilius.
          </h1>
          <p className="text-muted-foreground text-lg md:text-xl mb-10 max-w-md font-body">
            15+ metų patirtis. 4.9/5 įvertinimas. Preciziškas meistriškumas kiekviename kirpime.
          </p>
          <a
            href="#rezervacija"
            className="inline-block bg-primary text-primary-foreground px-10 py-4 text-sm uppercase tracking-[0.2em] font-bold transition-all duration-300 hover:scale-105 active:scale-95 animate-pulse-gold"
          >
            Rezervuoti laiką
          </a>
        </motion.div>
      </div>

      {/* Watermark */}
      <div className="absolute right-4 md:right-8 top-1/2 -translate-y-1/2 text-foreground/5 font-display text-[8rem] md:text-[12rem] writing-mode-vertical select-none pointer-events-none hidden lg:block"
        style={{ writingMode: "vertical-rl" }}
      >
        IRON CROWN
      </div>
    </section>
  );
};

export default HeroSection;
