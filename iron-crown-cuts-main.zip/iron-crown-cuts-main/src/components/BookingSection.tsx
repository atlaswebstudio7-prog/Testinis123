import { motion } from "framer-motion";

const transition = { duration: 0.4, ease: [0.4, 0, 0.2, 1] as const };

const BookingSection = () => {
  return (
    <section id="rezervacija" className="section-padding">
      <div className="max-w-3xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={transition}
        >
          <p className="text-primary text-sm uppercase tracking-[0.3em] mb-4 font-body font-bold">Rezervacija</p>
          <h2 className="font-display text-4xl md:text-5xl text-foreground mb-6">
            Pasiruošęs <span className="text-primary">naujam stiliui?</span>
          </h2>
          <p className="text-muted-foreground font-body text-lg mb-10 max-w-lg mx-auto">
            Rezervuokite savo laiką jau dabar ir leiskite mūsų meistrams pasirūpinti jūsų stiliumi.
          </p>
          <a
            href="tel:+37060000000"
            className="inline-block bg-primary text-primary-foreground px-12 py-5 text-sm uppercase tracking-[0.2em] font-bold transition-all duration-300 hover:scale-105 active:scale-95 animate-pulse-gold"
          >
            Rezervuoti dabar
          </a>
        </motion.div>
      </div>
    </section>
  );
};

export default BookingSection;
