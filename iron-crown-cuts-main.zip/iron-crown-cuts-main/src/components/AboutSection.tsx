import { motion } from "framer-motion";
import toolsImage from "@/assets/gallery-tools.jpg";

const transition = { duration: 0.4, ease: [0.4, 0, 0.2, 1] as const };

const AboutSection = () => {
  return (
    <section id="apie" className="section-padding">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={transition}
        >
          <p className="text-primary text-sm uppercase tracking-[0.3em] mb-4 font-body font-bold">Apie mus</p>
          <h2 className="font-display text-4xl md:text-5xl text-foreground mb-8">
            Meistriškumas,{" "}
            <span className="text-primary">kuriuo galite pasitikėti</span>
          </h2>
          <div className="space-y-6 text-muted-foreground font-body leading-relaxed">
            <p>
              The Iron Crown Barbershop — tai vieta, kur tradicinis kirpėjo amatas susitinka su moderniu stiliumi.
              Mūsų komanda turi daugiau nei 15 metų patirties ir nuolat tobulina savo įgūdžius.
            </p>
            <p>
              Kiekvienas klientas gauna individualų dėmesį ir profesionalią konsultaciją.
              Mes naudojame tik aukščiausios kokybės įrankius ir produktus, kad rezultatas viršytų lūkesčius.
            </p>
          </div>
          <div className="grid grid-cols-3 gap-8 mt-10">
            {[
              { value: "15+", label: "Metų patirtis" },
              { value: "4.9", label: "Įvertinimas" },
              { value: "5000+", label: "Patenkintų klientų" },
            ].map((stat) => (
              <div key={stat.label}>
                <p className="font-display text-3xl text-primary">{stat.value}</p>
                <p className="text-sm text-muted-foreground font-body mt-1">{stat.label}</p>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ ...transition, delay: 0.2 }}
          className="relative"
        >
          <img
            src={toolsImage}
            alt="Profesionalūs kirpėjo įrankiai"
            className="w-full aspect-square object-cover luxury-shadow"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background/30 to-transparent" />
        </motion.div>
      </div>
    </section>
  );
};

export default AboutSection;
